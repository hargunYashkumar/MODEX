// Main JavaScript file for Resume Generator

document.addEventListener("DOMContentLoaded", function () {
  // Initialize tooltips
  const tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="tooltip"]')
  );
  const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });

  // Initialize popovers
  const popoverTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="popover"]')
  );
  const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl);
  });

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll(".alert:not(.alert-permanent)");
  alerts.forEach(function (alert) {
    setTimeout(function () {
      const bsAlert = new bootstrap.Alert(alert);
      bsAlert.close();
    }, 5000);
  });

  // Form validation
  const forms = document.querySelectorAll(".needs-validation");
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener(
      "submit",
      function (event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add("was-validated");
      },
      false
    );
  });

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    });
  });

  // Loading states for forms
  const submitButtons = document.querySelectorAll('form button[type="submit"]');
  submitButtons.forEach((button) => {
    button.closest("form").addEventListener("submit", function () {
      button.disabled = true;
      const originalText = button.innerHTML;
      button.innerHTML =
        '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Processing...';

      // Re-enable after 30 seconds as fallback
      setTimeout(() => {
        button.disabled = false;
        button.innerHTML = originalText;
      }, 30000);
    });
  });

  // Character counter for textareas
  const textareas = document.querySelectorAll("textarea[maxlength]");
  textareas.forEach((textarea) => {
    const maxLength = textarea.getAttribute("maxlength");
    const counter = document.createElement("small");
    counter.className = "text-muted";
    counter.textContent = `0/${maxLength} characters`;
    textarea.parentNode.appendChild(counter);

    textarea.addEventListener("input", function () {
      const currentLength = this.value.length;
      counter.textContent = `${currentLength}/${maxLength} characters`;

      if (currentLength > maxLength * 0.9) {
        counter.className = "text-warning";
      } else if (currentLength === parseInt(maxLength)) {
        counter.className = "text-danger";
      } else {
        counter.className = "text-muted";
      }
    });
  });

  // Auto-resize textareas
  const autoResizeTextareas = document.querySelectorAll("textarea.auto-resize");
  autoResizeTextareas.forEach((textarea) => {
    textarea.addEventListener("input", function () {
      this.style.height = "auto";
      this.style.height = this.scrollHeight + "px";
    });
  });

  // Phone number formatting
  const phoneInputs = document.querySelectorAll('input[type="tel"]');
  phoneInputs.forEach((input) => {
    input.addEventListener("input", function (e) {
      let value = e.target.value.replace(/\D/g, "");
      if (value.length >= 6) {
        value = value.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3");
      } else if (value.length >= 3) {
        value = value.replace(/(\d{3})(\d{3})/, "($1) $2");
      }
      e.target.value = value;
    });
  });

  // URL validation and formatting
  const urlInputs = document.querySelectorAll('input[type="url"]');
  urlInputs.forEach((input) => {
    input.addEventListener("blur", function () {
      let url = this.value.trim();
      if (url && !url.startsWith("http://") && !url.startsWith("https://")) {
        this.value = "https://" + url;
      }
    });
  });

  // Copy to clipboard functionality
  window.copyToClipboard = function (text) {
    navigator.clipboard
      .writeText(text)
      .then(function () {
        showToast("Copied to clipboard!", "success");
      })
      .catch(function (err) {
        console.error("Could not copy text: ", err);
        showToast("Failed to copy to clipboard", "error");
      });
  };

  // Toast notification system
  window.showToast = function (message, type = "info") {
    const toastContainer =
      document.getElementById("toast-container") || createToastContainer();

    const toast = document.createElement("div");
    toast.className = `toast align-items-center text-white bg-${
      type === "error" ? "danger" : type
    } border-0`;
    toast.setAttribute("role", "alert");
    toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;

    toastContainer.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();

    toast.addEventListener("hidden.bs.toast", function () {
      toast.remove();
    });
  };

  function createToastContainer() {
    const container = document.createElement("div");
    container.id = "toast-container";
    container.className = "toast-container position-fixed top-0 end-0 p-3";
    container.style.zIndex = "9999";
    document.body.appendChild(container);
    return container;
  }

  // Debounce function for search/filter inputs
  window.debounce = function (func, wait, immediate) {
    let timeout;
    return function executedFunction() {
      const context = this;
      const args = arguments;
      const later = function () {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      const callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
  };

  // Local storage helpers
  window.saveToLocalStorage = function (key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (e) {
      console.warn("Could not save to localStorage:", e);
      return false;
    }
  };

  window.loadFromLocalStorage = function (key) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      console.warn("Could not load from localStorage:", e);
      return null;
    }
  };

  // Form auto-save functionality
  const autoSaveForms = document.querySelectorAll(".auto-save");
  autoSaveForms.forEach((form) => {
    const formId = form.id || "unnamed-form";
    const saveKey = `form-autosave-${formId}`;

    // Load saved data
    const savedData = loadFromLocalStorage(saveKey);
    if (savedData) {
      Object.keys(savedData).forEach((name) => {
        const field = form.querySelector(`[name="${name}"]`);
        if (field) {
          field.value = savedData[name];
        }
      });
      showToast("Form data restored from auto-save", "info");
    }

    // Save on input
    const debouncedSave = debounce(() => {
      const formData = new FormData(form);
      const data = {};
      for (let [key, value] of formData.entries()) {
        data[key] = value;
      }
      saveToLocalStorage(saveKey, data);
    }, 1000);

    form.addEventListener("input", debouncedSave);

    // Clear on successful submit
    form.addEventListener("submit", function () {
      localStorage.removeItem(saveKey);
    });
  });

  // Progressive Web App support
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker
      .register("/sw.js")
      .then(function (registration) {
        console.log("SW registered: ", registration);
      })
      .catch(function (registrationError) {
        console.log("SW registration failed: ", registrationError);
      });
  }

  // Keyboard shortcuts
  document.addEventListener("keydown", function (e) {
    // Ctrl+S to save (prevent default and trigger form submit)
    if (e.ctrlKey && e.key === "s") {
      e.preventDefault();
      const form = document.querySelector("form");
      if (form) {
        form.dispatchEvent(new Event("submit"));
      }
    }

    // Ctrl+N for new resume
    if (e.ctrlKey && e.key === "n") {
      e.preventDefault();
      window.location.href = "/raw-data";
    }

    // Escape to close modals
    if (e.key === "Escape") {
      const modals = document.querySelectorAll(".modal.show");
      modals.forEach((modal) => {
        const bsModal = bootstrap.Modal.getInstance(modal);
        if (bsModal) bsModal.hide();
      });
    }
  });

  // Analytics helper (placeholder for future integration)
  window.trackEvent = function (eventName, properties = {}) {
    console.log("Event tracked:", eventName, properties);
    // Integration with analytics service would go here
  };

  // Error handling for failed AJAX requests
  window.handleAjaxError = function (error, userMessage = "An error occurred") {
    console.error("AJAX Error:", error);
    showToast(userMessage, "error");
  };

  // Lazy loading for images
  if ("IntersectionObserver" in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.classList.remove("lazy");
          imageObserver.unobserve(img);
        }
      });
    });

    document.querySelectorAll("img[data-src]").forEach((img) => {
      imageObserver.observe(img);
    });
  }

  // Print functionality
  window.printElement = function (elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;

    const printWindow = window.open("", "", "height=600,width=800");
    printWindow.document.write("<html><head><title>Print</title>");
    printWindow.document.write(
      '<link rel="stylesheet" href="/static/css/style.css">'
    );
    printWindow.document.write("</head><body>");
    printWindow.document.write(element.innerHTML);
    printWindow.document.write("</body></html>");
    printWindow.document.close();
    printWindow.print();
  };

  // File size formatter
  window.formatFileSize = function (bytes, decimals = 2) {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
  };

  // Initialize any existing components
  initializeComponents();
});

// Component initialization function
function initializeComponents() {
  // Initialize any dynamic components that might be added later
  const cards = document.querySelectorAll(".card");
  cards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transition = "transform 0.3s ease, box-shadow 0.3s ease";
    });
  });
}

// API helper functions
window.apiCall = async function (url, options = {}) {
  try {
    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    handleAjaxError(error);
    throw error;
  }
};

// Resume-specific functions
window.ResumeApp = {
  // Save resume draft
  saveDraft: function (formData) {
    const draftKey = "resume-draft";
    saveToLocalStorage(draftKey, formData);
    showToast("Draft saved", "success");
  },

  // Load resume draft
  loadDraft: function () {
    const draftKey = "resume-draft";
    return loadFromLocalStorage(draftKey);
  },

  // Clear resume draft
  clearDraft: function () {
    localStorage.removeItem("resume-draft");
  },

  // Validate resume data
  validateResumeData: function (data) {
    const errors = [];

    if (!data.full_name || data.full_name.trim() === "") {
      errors.push("Full name is required");
    }

    if (!data.email || data.email.trim() === "") {
      errors.push("Email is required");
    } else if (!this.isValidEmail(data.email)) {
      errors.push("Please enter a valid email address");
    }

    return errors;
  },

  // Email validation
  isValidEmail: function (email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  // Phone number formatting
  formatPhoneNumber: function (phoneNumber) {
    const cleaned = phoneNumber.replace(/\D/g, "");
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    return phoneNumber;
  },

  // Preview resume
  previewResume: function (resumeData) {
    // Implementation would generate preview
    console.log("Previewing resume:", resumeData);
  },
};

// Export functions for use in other scripts
if (typeof module !== "undefined" && module.exports) {
  module.exports = { ResumeApp, showToast, debounce };
}
